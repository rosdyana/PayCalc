<?php
defined('_JEXEC') or die('Direct Access to this location is not allowed.');

/**
 * @version 1.0.0
 * @package PayrollCalculator 
 * @copyright 2016 RosdyanaKusuma
 * @author 2016 RosdyanaKusuma(rosdyana.kusuma@mail.com)
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @description Payroll Calculator
 * Homepage: http://r3m1ck.us/
*/

   require JModuleHelper::getLayoutPath('mod_payrollcalc');
?>